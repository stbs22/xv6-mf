Tarea 4
Alumno: Matias Ignacio Hermosilla Colilaf
Fecha: 21/11/2022

 Modificaciones que se realizaron a la carpeta xv6 public.


 1) La función que se creó fue llamada traduccion y traduce la direccion virtual de un input a su direccion fisica.
    Para comenzar se modificó el archivo syscall.c agregando los siguientes codigos sys_traduccion(void) junto a [SYS_traduccion]
 2) Se modificó el archivo sysproc.c, donde se añadió la siguiente función en la linea 98
    int
    sys_traduccion(uint *s){
    int i_s = (uint) s;
    argint(0, &i_s);
    return traduccion(i_s);
    Aqui basicamente se cambian los valores de entrada a enteros


 3) Se modifican los siguientes archivos user.h agregando int_traduccion(uint*); en la linea 27
    Luego se modificó defs.h agregando int    traduccion(uint); en el apartado de vm.c, especificamente en la linea 190
    Despues se modificó usys.s añadiendo el siguiente código SYSCALL(traducción) en la siguiente linea 33

 4) Se modifica el archivo vm.c, el cual contiene variables de la memoria virtual.Desde la linea 387 a la 411. El siguiente código fue extraido de un repositorio, sin embargo se cambiaron algunas variables para adaptarlo a las necesidades de la tarea
 int traduccion(uint vm) {
    struct proc *p = myproc();
    char *fm;
    pde_t *pgdir;
    pde_t *pde;
    pte_t *pte;
    pte_t *pgtab;
    pgdir = p->pgdir;
    pde = &pgdir[PDX(vm)];
    if ((*pde & PTE_P) && (*pde & PTE_U)) {
      pgtab = (pte_t*) P2V(PTE_ADDR(*pde));
      pte = &pgtab[PTX(vm)];
      fm = (char*) PTE_ADDR(*pte);

      cprintf("\nIngresaste el siguiente número: %d\n", vm);
      cprintf("Memoria Virtual asociada al número : 0x%x\n", vm);
      cprintf("Memoria Fisica asociada al número : 0x%x\n", fm);
    } else {
      cprintf("\n Page Fault \n");
      return -1;
    }
    return 0;
 Utilizamos el %x para pasar los numeros a hexadecimales
 Tratando de entender el código, logre identificar que PDX es una funcion asociada a la traduccion de memorias, junto con otras que se encuentran en el codigo.

 Gracias a al funcion que agregamos en el apartado 2, podemos obtener de forma decimal el número que ingresamos por pantalla.
 5) Tambien se deben hacer los cambios respectivos en el Makefile, los cuales son agregar _traduccion\ en la linea 187 , junto con traduccion.c\ en la linea 257


 6) Finalmente agregamos el siguiente código en syscall.h #define SYS_traduccion 23, en la linea 24
