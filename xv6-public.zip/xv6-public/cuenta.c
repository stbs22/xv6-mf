#include "types.h"
#include "stat.h"
#include "user.h"



int main(void){
printf("la cantidad de procesos en ejecucion en la CPU es %i",getprocs());
exit();
}
