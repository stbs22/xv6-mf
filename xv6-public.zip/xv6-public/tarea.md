Curso: Sistemas Operativos Sección 1
Alumno: Matías Ignacio Hermosilla Colilaf
A continuación se mencionaran las lineas que se cambiaron para realizar la tarea.
//////////////////////////////////////////////////////////////////////////////////////////////////////////

1)Editamos el archivo syscall.h, donde agregamos en la linea 23 lo siguiente "#define SYS_getprocs 22".
//////////////////////////////////////////////////////////////////////////////////////////////////////////
2)Editamos el archivo defs.h, donde en la linea 124 lo siguiente:"int     getprocs(void)".
//////////////////////////////////////////////////////////////////////////////////////////////////////////
3)Editamos el archivo user.h donde en la linea 22 agregamos "int getprocs()".
//////////////////////////////////////////////////////////////////////////////////////////////////////////
4)Editamos el archivo sysproc.c, donde agregamos en la última linea(linea 92) lo siguiente
int
sys_getprocs(void)
{
  return getprocs();
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////
5)Editamos el archivo usys.S, donde agregamos lo siguiente en la linea 21 de código "SYSCALL(getprocs)"
//////////////////////////////////////////////////////////////////////////////////////////////////////////
6)Editamos el archivo syscall.c donde agregamos la siguiente linea de código 94 "extern int sys_getprocs(void)" y luego más abajo en la linea 125 lo siguiente "[SYS_getprocs] sys_getprocs".
7)Ahora se debe implementar la función en el archivo proc.c. Para esto utilicé el siguiente código, implementandolo en la linea 536.
int
getprocs(void){
   struct proc *p;
   int cont = 0;
   acquire(&ptable.lock);
   for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->state != UNUSED)
         cont++;
   }
    release(&ptable.lock);
   return cont;

}
//////////////////////////////////////////////////////////////////////////////
8)Creamos un archivo getprocs.c con touch getprocs.c y agregamos lo siguiente.
#include "types.h"
#include "stat.h"
#include "user.h"

int main(void) {

 printf(1,"La cantidad de procesos ejecutandose en el sistema son %d\n",getprocs());
 exit();

}

 
