#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
  int flag_vmfm;
  char *s;
  uint n; 
  int f = 1;
  int vm = 0;

  n = 0;
  if (argc == 3) {
    f = -1;
    if (argv[2] != 0) {
      s = argv[2];
      n = atoi(s);
      vm = (n * f);
    }
  } else {
    if (argc == 2) {
      s = argv[1];
      n = atoi(s);
      vm = n;
    }
  }
  flag_vmfm = traduccion((uint *) vm);
  if (flag_vmfm == -1) {
    printf(1,"ERROR\n", vm);  

  }
  exit();
}
